#include <iostream>
int main()
{
    std::cout << "Hello Universe\n";
    return 0;
}
